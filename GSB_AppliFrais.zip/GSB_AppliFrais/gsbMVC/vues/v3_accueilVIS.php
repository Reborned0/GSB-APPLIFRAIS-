<div class="contenu">
    <h2>Bienvenue sur l'application GSB APPLI FRAIS - Espace visiteur</h2>
    <div class="contenu_interne">
        <p>
            Cette application vous permet :
            <ul>
                <li>De déclarer vos frais dans la partie "Saisir fiche de frais"</li>
                <li>De consulter l'évolution du traitement de vos fiches de frais et de votre historique dans la partie "Mes fiches de frais"</li>
            </ul>
        </p>
    </div>
</div>

