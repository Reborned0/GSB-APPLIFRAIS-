<div class="contenu">
    <h2>Bienvenue sur l'application GSB APPLI FRAIS - Espace comptable</h2>
    <div class="contenu_interne">
        <p>
           Cette application vous permet :
            <ul>
                <li>De contrôler et valider les fiches de frais des visiteurs dans la partie "Valider fiche de frais"</li>
                <li>De mettre en paiement et de consulter l'historique des fiches de frais des visiteurs dans la partie "Suivre paiement fiche de frais"</li> 
            </ul>
        </p>
    </div>
</div>

