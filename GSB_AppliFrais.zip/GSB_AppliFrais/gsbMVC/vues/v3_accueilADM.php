﻿<div class="contenu">
    <h2>Bienvenue sur l'application GSB APPLI FRAIS - Espace administrateur</h2>
    <div class="contenu_interne">
        <p>
            L'espace d'administration du site vous permet de gérer les catégories "de base" de l'application GSB APLLI FRAIS, ainsi que les comptes utilisateurs. 
        </p>
    </div>
</div>
