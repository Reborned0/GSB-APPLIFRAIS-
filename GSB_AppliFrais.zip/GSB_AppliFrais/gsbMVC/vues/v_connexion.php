<div class="contenu">
    
    <h2>Identification utilisateur</h2>

   <form method="POST" action="index.php?uc=connexion&action=valideConnexion">    
         <p>
             
             <input id="login" type="text" name="login" placeholder="Login*"  size="30" maxlength="45">
         </p>
         <p>
            
             <input id="mdp"  type="password"  name="mdp" placeholder="Mot de passe*" size="30" maxlength="45">
        </p>
             <input type="submit" value="Connexion" name="valider">
             <input type="reset" value="Annuler" name="annuler"> 
      
   </form>
</div>


