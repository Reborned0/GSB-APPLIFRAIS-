<div class="contenu">
    <div class="contenu_interne">
        <h2>Ajouter un nouveau type d'employé : </h2>
        <form method="POST" action="index.php?uc=gererCatEmploye&action=validerCreationCatEmploye">
            <label for="idCatEmploye">ID* :
                <input type="text" name="idCatEmploye" id="idCatEmploye">
            </label>
            <label for="libelleCatEmploye">Libellé catégorie* :
                <input type="text" name="libelleCatEmploye" id="libelleCatEmploye">
            </label>
            <div class="piedForm">
                   <input class="btn btn-success" type="submit" value="Valider" size="20" />
                <a href="index.php?uc=gererCatEmploye&action=voirCatEmploye">
                   <input class="btn btn-danger" type="reset" value="Annuler" size="20" />
                </a>
            </div>
            
            </a>
        </form>    
    </div>
</div>
