<div class="contenu">
    <div class="contenu_interne">
        <h2>Ajouter un nouvel utilisateur :</h2>
        <form method="POST" action="index.php?uc=gererCptUtilisateur&action=validerCreationCptUtilisateur">
            <p>
            <label for="nomEmploye">Nom* :</label>
               <input type="text" name="nomEmploye" id="nomEmploye" size="30" maxlength="45">
            </p>
            <p>
            <label for="prenomEmploye">Prénom* :</label>
                <input type="text" name="prenomEmploye" id="prenomEmploye" size="30" maxlength="45">
            </p>
            <p>
            <label for="adresseEmploye">Adresse* :</label>
                <input type="text" name="adresseEmploye" id="adresseEmploye" size="30" maxlength="45">
            </p>
            <p>
            <label for="localisation">CP - Ville* :</label>
                <select name="localisation" id="localisation">
                    <option value="0"></option>
                    <?php
                    for ($i=0;$i<count($localisation);$i++){
                        echo '<option value="' . $localisation[$i]['idLocalisation'] . '">' . $localisation[$i]['libelleVille'] . ' [' . $localisation[$i]['codePostal'] . ']</option>';
                    }
                    ?>
                </select>
            </p>
            <p>
            <label for="loginEmploye">Login* :</label>
                <input type="text" name="loginEmploye" id="loginEmploye" size="30" maxlength="45">
            </p>
            <p>
            <label for="mdpEmploye">Mot de passe* :</label>
                <input type="text" name="mdpEmploye" id="mdpEmploye" size="30" maxlength="45">
            </p>
            <p>
            <label for="dateEmbaucheEmploye">Date d'embauche (jj/mm/aaaa)* :</label>
                <input type="date" name="dateEmbaucheEmploye" id="dateEmbaucheEmploye" size="30" maxlength="45">
            </p>
            <p>
            <label for="typeEmploye">Type employé* :</label>
                <select name="typeEmploye" id="typeEmploye">
                    <option value="0"></option>
                    <?php
                    for ($i=0;$i<count($lesCatEmploye);$i++){
                        echo '<option value="' . $lesCatEmploye[$i]['idTypeEmploye'] . '">' . $lesCatEmploye[$i]['libelleTypeEmploye'] . '</option>';
                    }
                    ?>
                </select>
            </p>
            <p>
            <label for="fraisKm">Type du véhicule (si véhicule)* :</label>
                <select name="fraisKm" id="fraisKm">
                    <option value="0"></option>
                    <?php
                    for ($i=0;$i<count($lesCatFraisKm);$i++){
                        echo '<option value="' . $lesCatFraisKm[$i]['idTypeVehicule'] . '">' . $lesCatFraisKm[$i]['libelleTypeVehicule'] . '</option>';
                    }
                    ?>
                </select>
            <br/>
            <p>
                <label for="cpt">Compte :</label>
                <input type="radio" name="activationCptEmploye" id="cptActif" value="1" checked /> Actif
                <input type="radio" name="activationCptEmploye" id="cptInactif" value="0" /> Inactif
            </p>
            
            <input class="btn btn-success btn-sm" type="submit" value="Valider">
            <a href="index.php?uc=gererCptUtilisateur&action=voirCptUtilisateur">
            <input class="btn btn-danger btn-sm" type="reset" value="Annuler">
            </a>
        </form>
    </div>
</div>

