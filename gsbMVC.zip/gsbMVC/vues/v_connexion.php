<div class="contenu">
    
    <h2>Identification utilisateur</h2>

   <form method="POST" action="index.php?uc=connexion&action=valideConnexion">    
         <p>
             <label for="nom">Identifiant*</label>
             <input id="login" type="text" name="login" size="30" maxlength="45"/>
         </p>
         <p>
             <label for="mdp">Mot de passe*</label>
             <input id="mdp"  type="password"  name="mdp" size="30" maxlength="45"/>
        </p>
             
             
             <input class="btn btn-success " type="submit" value="Valider">
             <input class="btn btn-danger " type="reset" value="Annuler">
             
             
      
   </form>
</div>


